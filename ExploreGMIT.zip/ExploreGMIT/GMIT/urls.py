from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [
    path('', views.index, name='home'),
    path('index/', views.index, name='home'),
    path('about/', views.about, name='about'),
    path('Career_DC/', views.Career_DC, name='Career_DC'),
    path('admission/', views.admission, name='admission'),
    path('Administration/', views.Administration, name='Administration'),
    path('contact/', views.contact, name='contact'),
    path('tech_single/', views.tech_single, name='tech_single'),
    path('Admin_login/', views.Admin_login, name='Admin_login'),
    path('user_login/', views.user_login, name='user_login'),
    path('Admin_registration/', views.Admin_registration, name='Admin_registration'),
    path('web_series/', views.web_series, name='web_series'),
    path('CSE/', views.CSE, name='CSE'),
    path('form/', views.form, name='form'),
    path('sport_form/', views.sport_form, name='sport_form'),
    path('ECE/', views.ECE, name='ECE'),
    path('CE/', views.CE, name='CE'),
    path('ME/', views.ME, name='ME'),
    path('EE/', views.EE, name='EE'),
    path('BSH/', views.BSH, name='BSH'),

    path('student_profile/', views.student_profile, name='student_profile'),
    path('student_dashboard/', views.student_dashboard, name='student_dashboard'),
    path('student_addnews/', views.student_addnews, name='student_addnews'),
    path('student_profile_edit/', views.student_profile_edit, name='student_profile_edit'),
]