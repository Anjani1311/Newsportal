from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def index(request):
    return render(request,'index.html')

def about(request):
    return render(request,'about.html')

def Career_DC(request):
    return render(request,'Career_DC.html')

def admission(request):
    return render(request,'admission.html')

def contact(request):
    return render(request,'contact.html')

def tech_single(request):
    return render(request,'tech_single.html')
    
def Admin_login(request):
    return render(request,'Admin_login.html')

def user_login(request):
    return render(request,'user_login.html')

def Admin_registration(request):
    return render(request,'Admin_registration.html')

def web_series(request):
    return render(request,'web_series.html')

def CSE(request):
    return render(request,'CSE.html')

def form(request):
    return render(request,'form.html')

def sport_form(request):
    return render(request,'sport_form.html')

def ECE(request):
    return render(request,'ECE.html')

def CE(request):
    return render(request,'CE.html')

def ME(request):
    return render(request,'ME.html')

def EE(request):
    return render(request,'EE.html')

def BSH(request):
    return render(request,'BSH.html')

def Administration(request):
    return render(request,'Administration.html')


def student_profile(request):
    return render(request,'student_profile.html')

def student_dashboard(request):
    return render(request,'student_dashboard.html')

def student_addnews(request):
    return render(request,'student_addnews.html')

def student_profile_edit(request):
    return render(request,'student_profile_edit.html')
